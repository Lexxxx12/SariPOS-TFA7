@extends('layouts.app')

@section('content')
    <section class="relative mx-3 mt-4 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-lg shadow-slate-900/5 sm:mx-5 lg:mx-8 lg:mt-8">
        <div class="absolute -right-24 -bottom-56 size-96 rounded-full border-[4rem] border-teal-50" aria-hidden="true"></div>
        <div class="relative mx-auto max-w-6xl px-6 py-9 sm:px-10 lg:px-12">
            <p class="text-xs font-extrabold tracking-[0.18em] text-teal-700 uppercase">Account directory</p>
            <div class="mt-2 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <h1 class="text-4xl font-black tracking-[-0.05em]">Customer Accounts</h1>
                    <p class="mt-2 text-sm text-slate-500">Contact details for the store's registered customers.</p>
                </div>
                <span class="w-fit rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-extrabold text-slate-600">{{ count($customers) }} records</span>
                <a class="rounded-xl bg-navy px-5 py-3 text-sm font-bold text-white hover:bg-coral" href="{{ route('customers.create') }}">+ Create Customer</a>
            </div>
        </div>
    </section>

    <section class="mx-auto max-w-6xl px-5 py-8 sm:px-8 lg:py-10">
        <div class="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-lg shadow-slate-900/5">
            <div class="overflow-x-auto">
                <table class="w-full min-w-3xl text-left">
                    <thead class="bg-slate-100 text-[0.7rem] tracking-[0.12em] text-slate-500 uppercase">
                        <tr>
                            <th class="px-6 py-4 font-extrabold">Customer</th>
                            <th class="px-6 py-4 font-extrabold">Email address</th>
                            <th class="px-6 py-4 font-extrabold">Phone number</th>
                            <th class="px-6 py-4 font-extrabold">Date created</th>
                        <th class="px-6 py-4 font-extrabold">Actions</th></tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-sm">
                        @forelse ($customers as $customer)
                            <tr class="hover:bg-slate-50/80">
                                <td class="px-6 py-5">
                                    <div class="flex items-center gap-3">
                                        <span class="grid size-10 shrink-0 place-items-center rounded-xl bg-teal-50 text-xs font-black text-teal-700">{{ str($customer->full_name)->substr(0, 1)->upper() }}</span>
                                        <span><strong class="block">{{ $customer->full_name }}</strong><small class="text-xs text-slate-400">CUS-{{ str_pad((string) $customer->id, 4, '0', STR_PAD_LEFT) }}</small></span>
                                    </div>
                                </td>
                                <td class="px-6 py-5"><a class="font-semibold text-coral hover:underline" href="mailto:{{ $customer->email }}">{{ $customer->email }}</a></td>
                                <td class="px-6 py-5 whitespace-nowrap text-slate-600">{{ $customer->phone ?? '—' }}</td>
                                <td class="px-6 py-5"><span class="rounded-full bg-teal-50 px-2.5 py-1 text-xs font-extrabold text-teal-700">{{ $customer->created_at->format('M j, Y') }}</span></td>
                                <td class="px-6 py-5"><a class="rounded-lg border border-slate-200 px-4 py-2 text-xs font-bold text-teal-700 hover:bg-teal-50" href="{{ route('customers.edit', $customer) }}" aria-label="Edit {{ $customer->full_name }}">Edit</a></td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="px-6 py-10 text-center text-slate-500">No customers records yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </section>
@endsection
